declare module "bundle-text:*" {
  const value: string;
  export default value;
}
