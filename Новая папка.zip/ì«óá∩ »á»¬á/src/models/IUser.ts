export interface IUser {
    fio: string
    email: string
    phone_number: number
    category: string
} 