export interface IContact {
  _id?: number;
  fio: string;
  email: string;
  phone_number: number;
  category: string;
}
