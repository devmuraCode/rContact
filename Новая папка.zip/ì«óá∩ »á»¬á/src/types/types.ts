export type AuthorizationType = {
    username: string;
    password: string;
};